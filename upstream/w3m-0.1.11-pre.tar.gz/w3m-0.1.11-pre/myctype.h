#include <ctype.h>

#define IS_SPACE(x) (!(x&~127) && isspace(x))
#define IS_ALNUM(x) (!(x&~127) && isalnum(x))
#define IS_ALPHA(x) (!(x&~127) && isalpha(x))
#define IS_DIGIT(x) (!(x&~127) && isdigit(x))
#define IS_PRINT(x) (!(x&~127) && isprint(x))
#define IS_CNTRL(x) (!(x&~127) && iscntrl(x))
#define IS_DIGIT(x) (!(x&~127) && isdigit(x))
