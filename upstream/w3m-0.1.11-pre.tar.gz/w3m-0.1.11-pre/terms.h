extern int LINES, COLS;

extern char DisplayCode;

#define CODE_EUC  'E'
#define CODE_SJIS 'S'
#define CODE_JIS1 'n'
#define CODE_JIS2 'm'
#define CODE_JIS3 'N'
#define CODE_JIS4 'j'

#if defined(__EMX__)&&!defined(JP_CHARSET)
/*
 * Following definitions are valid only for the OS/2 native console
 */
#define CODE_850  '8'	/* code page 850	*/
#define CODE_PC	  'P'	/* another code pages	*/
#endif			/* __EMX__ */

#define CODE_JIS(x) ((x)==CODE_JIS1||(x)==CODE_JIS2||(x)==CODE_JIS3||(x)==CODE_JIS4)
