#ifndef TEXTLIST_H
#define TEXTLIST_H

typedef struct _textlistitem {
    char *ptr;
    struct _textlistitem *next;
    struct _textlistitem *prev;
} TextListItem;

typedef struct _textlist {
    TextListItem *first;
    TextListItem *last;
    short nitem;
} TextList;

extern TextListItem *newTextListItem(char *s, TextListItem * n, TextListItem * p);
extern TextList *newTextList(void);
extern void pushText(TextList * tl, char *s);
extern void appendText(TextList * tl, char *s);
extern char *popText(TextList * tl);
extern TextList *appendTextList(TextList *, TextList *);

#endif				/* not TEXTLIST_H */
